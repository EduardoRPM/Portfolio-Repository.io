import greenfoot.*;
import java.awt.Rectangle;

public class Corredor extends World
{
    protected GreenfootImage[] images;
    protected int currentBackgroundIndex = 0;
    protected YellowCircle yc = new YellowCircle(70);
    protected GreenfootSound amb;
    protected int z,limite;
    protected Corazon c1, c2,c3;
    protected int n,banderaNivel;
    protected Fed fedIn;
    
    public Corredor(int n, int banderaNivel, String prefix, int increment, int limite) {    
        super(1280, 720, 1);
        this.limite=limite;
        this.n=n;
        this.banderaNivel=banderaNivel;
        
        if(n==2){
        c1=new Corazon();
        c2=new Corazon();
        addObject(c1, 275 , 70 );
        addObject(c2, 350 , 70 );
        } else if(n==1){
            c1=new Corazon();
            addObject(c1, 275 , 70 );
        } else if(n==3){
            c1=new Corazon();
            c2=new Corazon();
            c3=new Corazon();
            addObject(c3, 425 , 70 ); 
            addObject(c2, 350 , 70 );
            addObject(c1, 275 , 70 );
        }

        Principal principal = new Principal();
        addObject(principal, getWidth()-1000 , getHeight()-50);
        initBackgrounds(prefix, increment, limite);
        setBackground(images[currentBackgroundIndex]);
        addObject(yc, getWidth()/2 , getHeight()/2 );
        amb = new GreenfootSound("sounds/amb2.mp3");
        amb.playLoop();
        
    }

    public void act()
    {
        checkKeyPressBck();
    }

    public void checkKeyPressBck()
    {
        if (Greenfoot.isKeyDown("w"))
        {
            Greenfoot.delay(5);
            currentBackgroundIndex = (currentBackgroundIndex + 1) % images.length;
            setBackground(images[currentBackgroundIndex]);
            clearPreviousBackground();
            z++;
            if(z>limite-2){
                fedIn = new Fed();
                addObject(fedIn ,getWidth()/2 , getHeight()/2);
                fedIn.fedOutAnim();
                amb.stop();
                Greenfoot.setWorld(new BlackWorld(n,banderaNivel));
            }
        }
    }
  
    public void clearPreviousBackground() {
        int previousIndex = (currentBackgroundIndex - 1 + images.length) % images.length;
        images[previousIndex].clear();
    }

    protected void initBackgrounds(String prefix, int increment,int limite) {
        images = new GreenfootImage[limite];
        int index = 1;
        for (int i = 0; i < images.length; i++) {
            String formattedIndex = String.format("%04d", index);
            String filename = prefix + formattedIndex + ".jpg";
            images[i] = new GreenfootImage(filename);
            index += increment; 
        }
    }
}
