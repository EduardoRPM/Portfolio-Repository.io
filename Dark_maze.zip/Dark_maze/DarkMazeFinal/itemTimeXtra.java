import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class itemTimeXtra here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class itemTimeXtra extends Actor
{
    private Timer timer; // aproximadamente 60 segundos = 55 * 10
    private GreenfootImage[] itemTime = new GreenfootImage[3];
    private int count=100;
    private boolean bandera=true;
    private int delayCounter = 0;
    private int delayDuration = 10; 
    private int animIdleCounter = 0;
    CircleCollider c;
    public itemTimeXtra(Timer timer, CircleCollider c)
    {
        this.timer=timer;
        this.c=c;
        initAnimationSprites();
    }


    public void act() {
        checkCollision();
    }
    
     public void checkCollision() {
     c = (CircleCollider) getOneIntersectingObject(CircleCollider.class);
     
    if (timer.getTime()<100 && bandera==true) {
        animateIdleWithDelay();
        if (c != null) {
          timer.setTime(450);
          GreenfootImage image = new GreenfootImage("Overtime activated", 30, Color.GREEN, Color.BLACK);
          setImage(image);
          bandera=false;
        }
    }
}
      public void animateIdleWithDelay() {
        if (delayCounter < delayDuration) {
            delayCounter++;
        } else {
            setImage(itemTime[animIdleCounter % 3]);
            animIdleCounter++;
            delayCounter = 0;
        }
       
    }
  
    public void initAnimationSprites() {
        for (int i = 0; i < 3; i++) {
            String filename = "SSBUTimer" + i + ".png";
            itemTime[i] = new GreenfootImage(filename);
        }
    }
    
   
}
