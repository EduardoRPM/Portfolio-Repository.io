import greenfoot.*;  

public abstract class BaseWorld extends World
{
    protected GreenfootImage[] backgrounds;
    protected int currentBackgroundIndex = 0;
    protected int z=0;
    protected boolean start = false;

    public BaseWorld(int numberOfImages, String imagePrefix, int indexStart, int indexStep)
    {    
        super(1280, 720, 1);
        backgrounds = new GreenfootImage[numberOfImages];
        initBackgrounds(imagePrefix, indexStart, indexStep);
        setBackground(backgrounds[currentBackgroundIndex]);
    }

    public void act()
    {
        checkKeyPressBck();
    }

    public void checkKeyPressBck()
    {
        Greenfoot.delay(7);
        currentBackgroundIndex = (currentBackgroundIndex + 1) % backgrounds.length;
        setBackground(backgrounds[currentBackgroundIndex]);
        if(currentBackgroundIndex==backgrounds.length-1){
            Greenfoot.delay(8);
            Greenfoot.setWorld(new Inicio());
        }
        clearPreviousBackground();
    }

    public void initBackgrounds(String imagePrefix, int indexStart, int indexStep) {
        int index = indexStart;
        for (int i = 0; i < backgrounds.length; i++) {
            String formattedIndex = String.format("%04d", index);
            String filename = imagePrefix + formattedIndex + ".jpg";
            backgrounds[i] = new GreenfootImage(filename);
            index += indexStep; 
        }
    }

    public void clearPreviousBackground() {
        int previousIndex = (currentBackgroundIndex - 1 + backgrounds.length) % backgrounds.length;
        backgrounds[previousIndex].clear();
    }
}