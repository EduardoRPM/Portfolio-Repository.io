import greenfoot.*;
import greenfoot.GreenfootSound;

public class Fin extends BaseWorld
{
    
    private GreenfootSound outside;
    public Fin()
    {    
        super(15, "fin", 20, 19);
        outside = new GreenfootSound("sounds/fin.mp3");
    }
    @Override
    public void checkKeyPressBck()
    {   
        if (Greenfoot.isKeyDown("space")){
            start = true;
            
        }
        if (start == true)
        {
            super.checkKeyPressBck();
            z++;
            if(z==10){
                outside.play();
            }
            if(z>20){
                if(Greenfoot.isKeyDown("space")){
                    outside.stop();
                    Greenfoot.setWorld(new Inicio());
                }
            }
        }
    }
}